/*
    Coder: Bruno
    Email: rbruno2k15@outlook.com
*/

#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "../src/xs_postgresql.c"

int IO_R_counter = 0;
int r_header = 1;
int w_header = 1;
int is_exec = 0;

char* input[] =
{
    "OPEN bruno test testdb",
    // "CLOSE 1",
    "EXEC 1 DROP TABLE COMPANY",
    "EXEC 1 CREATE TABLE COMPANY("  \
      "ID INT PRIMARY KEY     NOT NULL," \
      "NAME           TEXT    NOT NULL," \
      "AGE            INT     NOT NULL," \
      "ADDRESS        TEXT," \
      "SALARY         REAL );",
    "EXEC 1 INSERT INTO COMPANY "  \
         "VALUES (1, 'Paul', 32, 'California', 20000.00 ); ",
    "EXEC 1 INSERT INTO COMPANY  "  \
         "VALUES (2, 'Allen', 25, 'Texas', 15000.00 ); ",
    "EXEC 1 INSERT INTO COMPANY " \
         "VALUES (3, 'Teddy', 23, 'Norway', 20000.00 );",
    "EXEC 1 INSERT INTO COMPANY " \
         "VALUES (4, 'Mark', 25, 'Rich-Mond', 65000.00 );",
    "EXEC 1 SELECT * FROM COMPANY;",
    "EXECOF bin/files/test.file 1 SELECT * FROM COMPANY;",
    "EXEC 1 DROP TABLE Music",
    "EXEC 1 CREATE TABLE Music(Id INTEGER PRIMARY KEY NOT NULL, Name TEXT NOT NULL, Data bytea);",
    // "BLOBIN 1 Music Runaway.mp3 tests/files/Runaway.mp3",
    // "BLOBOUT 1 Music Runaway.mp3 bin/files/Runaway.mp3",
    // "BLOBIN 1 Music 02.Runaway.mp3 tests/files/Runaway.mp3",
    // "BLOBOUT 1 Music 02.Runaway.mp3 bin/files/Runaway.mp3",
    // "CLOSE 1",
    "TERMINATE"
};

int64_t IO_R_dummy(char *buf, int64_t len)
{
    if(r_header)
    {
        int64_t tmp = strlen(input[IO_R_counter]);
        swapbo64(tmp);
        memcpy(buf, (char*)&tmp, len);
    }
    else
    {
        memcpy(buf, input[IO_R_counter], len);
        IO_R_counter++;
    }

    r_header = 1 - r_header;

    return 0;
}

int64_t IO_W_dummy(char *buf, int64_t len)
{
    if(w_header)
    {
        int64_t temp = *(int64_t*)buf;
        swapbo64(temp);
        
        if(!temp)
        {
            is_exec = 0;
            printf("0\n");
            return 0;    
        } 

        if(is_exec)
        {
            printf("%s\n", buf);
            return 0;
        }
        
        printf("%lu\n", temp);
    } 
    else
    {
        // is_exec |= !strcmp(buf, "5 EXEC OK");

        printf("%s\n", buf);
    }     

    w_header = 1 - w_header;

    return 0;
}

int Jaildir_dummy(const char *src, char *dst)
{
    strcpy(dst, src);
}

int main()
{
    printf("%d\n", xs_postgresql(IO_R_dummy, IO_W_dummy, Jaildir_dummy));

    return 0;
}