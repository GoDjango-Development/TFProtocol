# xs_postgresql

## Comandos:
* **open**: Abre una base de datos
    * Sintaxis: OPEN [HOST] [PORT] [USER] [PASSWORD] [DB_NAME]
    * Ejemplo: OPEN peter thebestpassword mydb
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 1 BD OPENED OK WITH ID [ID]
        * 2 FAILED OPEN POSTGRESQL CONNECTION

* **close**: Cierra una base de datos
    * Sintaxis: CLOSE [BD_ID]
    * Ejemplo: CLOSE 7
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 3 CLOSE OK
        * 4 FAILED CLOSE BD DOES NOT EXISTS

* **exec**: Ejecuta instrucciones sobre una base de datos
    * Sintaxis: EXEC [BD_ID] [SQL_QUERY]
    * Ejemplo: EXEC 5 SELECT * FROM Estudiantes;
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución, son:
        * 5 EXEC OK
        * 6 FAILED EXEC BD DOES NOT EXISTS
        * 7 FAILED EXEC POSTGRESQL
    * Nota: Cuando la función se ejecuta sin problemas envía al cliente "5 EXEC OK", si la consulta es un SELECT, es decir, que se pidieron datos, entonces se envía al cliente el header separando los nombres de las columnas por @@    
    Ejemplo: ID@@NAME@@LASTNAME     
    Luego, se envían las filas de la consulta, una a una, con este mismo formato.  
    Ejemplo:  
    2@@Pedro@@Pérez  
    3@@María@@Rodríguez

* **execof**: Ejecuta instrucciones sobre una base de datos y guarda la salida en un fichero
    * Sintaxis: EXECOF [PATH] [BD_ID] [SQL_QUERY]
    * Ejemplo: EXECOF path/to/myfile 5 SELECT * FROM Estudiantes;
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución, son:
        * 8 EXECOF OK
        * 9 FAILED EXECOF BD DOES NOT EXISTS
        * 10 FAILED EXECOF POSTGRESQL
    * Nota: Cuando la función se ejecuta sin problemas envía al cliente "8 EXECOF OK", si la consulta es un SELECT, es decir, que se pidieron datos, entonces se agrega al path dado por el cliente el header separando los nombres de las columnas por @@    
    Ejemplo: ID@@NAME@@LASTNAME     
    Luego, se agregan las filas de la consulta, una a una, con este mismo formato.  
    Ejemplo:  
    2@@Pedro@@Pérez  
    3@@María@@Rodríguez

* **exit**: finaliza la ejecución de xs_postgresql y no libera los recursos
    * Sintaxis: EXIT
    
* **terminate**: finaliza la ejecución de xs_postgresql y libera los recursos
    * Sintaxis: TERMINATE
