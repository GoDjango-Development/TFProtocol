/*
    Coder: Bruno
    Email: rbruno2k15@outlook.com
*/

#pragma once

#include <mysql.h>
#include <inttypes.h>

typedef struct node_list
{
    MYSQL* handler;
    struct node_list* next;
    struct node_list* prev;
    int64_t id;

} node_list;

typedef struct list
{
    node_list* head;
    node_list* tail;
    int size;

} list;

list* new_list();

node_list* find(list*, int);

int64_t push_back(list*, MYSQL*);

void erase(list*, node_list*);

void free_list(list* _list);

void print_list(list*);
