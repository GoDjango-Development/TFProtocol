/*
    Coder: Bruno
    Email: rbruno2k15@outlook.com
*/

#include "../src/infraestructure/list.h"
#include <stdio.h>

int main()
{
    list* _list = new_list();
    
    push_back(_list, "234", NULL);
    push_back(_list, "654", NULL);
    push_back(_list, "43", NULL);
    push_back(_list, "Open falksjd fksldjf", NULL);

    printf("%d", _list -> size);
    print_list(_list);

    node_list* node = find(_list, 1);

    if(node != NULL) 
    {
        printf("(%s)\n", node -> data);        
        erase(_list, node);
    }

    printf("%d\n", contains_db(_list, "43"));
    printf("%d\n", contains_db(_list, "44"));

    printf("%d", _list -> size);
    print_list(_list);

    return 0;
}