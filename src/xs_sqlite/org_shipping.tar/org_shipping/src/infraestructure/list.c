/*
    Coder: Bruno
    Email: rbruno2k15@outlook.com
*/

#include "list.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

list* new_list()  
{
    list* _list = (list*)malloc(sizeof(list));

    _list -> head = NULL;
    _list -> tail = NULL;
    _list -> size = 0;

    return _list;
}

int64_t push_back(list* _list, char* element, sqlite3* handler)
{
    node_list* new_node = (node_list*)malloc(sizeof(node_list));

    new_node -> data = element;
    new_node -> handler = handler;
    new_node -> next = NULL; 
    
    if(_list -> size == 0)
    {
        new_node -> prev = NULL;
        _list -> head = new_node;
        _list -> tail = new_node; 
        new_node -> id = 1;
    }
    else
    {
        new_node -> prev = _list -> tail;  
        _list -> tail -> next = new_node;        
        _list -> tail = new_node;
        new_node -> id = new_node -> prev -> id + 1;
    }

    _list -> size++;

    return new_node -> id;
}

node_list* find(list* _list, int id)
{
    if(_list -> size == 0)
        return NULL;

    node_list* current = _list -> head;

    while(current -> id != id) 
    {
        if(current -> next == NULL) 
            return NULL;
        else 
            current = current -> next;        
    }      

    return current;
}

void erase(list* _list, node_list* node)
{
    if(node -> prev == NULL && node -> next == NULL)
    {
        _list -> head = NULL;
        _list -> tail = NULL;
    }
    else if(node -> prev == NULL)
    {
        _list -> head -> prev = NULL;
        _list -> head = node -> next;
    }
    else if(node -> next == NULL)
    {
        _list -> tail = node -> prev;
        _list -> tail -> next = NULL;
    }
    else
    {
        node -> next -> prev = node -> prev;
        node -> prev -> next = node -> next;
    }
    
    _list -> size--;  

    free(node);
}

void free_list(list* _list)
{
    node_list* current;

    while(_list -> head != NULL)
    {
        current = _list -> head;
        _list -> head = _list -> head -> next;
        sqlite3_close(current -> handler);
        free(current);
    }
}

void print_list(list* _list)
{
    node_list *node = _list -> head;

    printf("[ ");

    while(node != NULL) 
    {
        printf("(%lu, %s) ", node -> id, node -> data);
        node = node -> next;
    }

    printf(" ]\n");    
}