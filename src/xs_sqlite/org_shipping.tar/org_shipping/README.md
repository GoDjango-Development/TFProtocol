# xs_sqlite

## Comandos:
* **open**: Abre una base de datos
    * Sintaxis: OPEN [PATH]
    * Ejemplo: OPEN path/to/mydb.bd
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 1 BD OPENED OK WITH ID [ID]
        * 2 FAILED OPEN SQLITE
        * 3 FAILED OPEN JAILDIR
    * Nota: Si PATH=":memory:" se creará la bd en memoria

* **exec**: Ejecuta instrucciones sobre una base de datos
    * Sintaxis: EXEC [BD_ID] [SQL_QUERY]
    * Ejemplo: EXEC 5 SELECT * FROM Estudiantes;
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución, son:
        * 4 EXEC OK
        * 5 FAILED EXEC BD DOES NOT EXISTS
        * 6 FAILED EXEC SQLITE
    * Nota: Cuando la función se ejecuta sin problemas envía al cliente "4 EXEC OK", si la consulta es un SELECT, es decir, que se pidieron datos, entonces se envía al cliente el header separando los nombres de las columnas por @@    
    Ejemplo: ID@@NAME@@LASTNAME     
    Luego, se envían las filas de la consulta, una a una, con este mismo formato.  
    Ejemplo:  
    2@@Pedro@@Pérez  
    3@@María@@Rodríguez

* **execof**: Ejecuta instrucciones sobre una base de datos y guarda la salida en un fichero
    * Sintaxis: EXECOF [PATH] [BD_ID] [SQL_QUERY]
    * Ejemplo: EXECOF path/to/myfile 5 SELECT * FROM Estudiantes;
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución, son:
        * 7 EXECOF OK
        * 8 FAILED EXECOF BD DOES NOT EXISTS
        * 9 FAILED EXECOF SQLITE
    * Nota: Cuando la función se ejecuta sin problemas envía al cliente "7 EXECOF OK", si la consulta es un SELECT, es decir, que se pidieron datos, entonces se agrega al path dado por el cliente el header separando los nombres de las columnas por @@    
    Ejemplo: ID@@NAME@@LASTNAME     
    Luego, se agregan las filas de la consulta, una a una, con este mismo formato.  
    Ejemplo:  
    2@@Pedro@@Pérez  
    3@@María@@Rodríguez

* **close**: Cierra una base de datos
    * Sintaxis: CLOSE [BD_ID]
    * Ejemplo: CLOSE 7
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 10 CLOSE OK
        * 11 FAILED CLOSE SQLITE
        * 12 FAILED CLOSE BD DOES NOT EXISTS

* **lastrowid**: Obtener el último id insertado en la bd solicitada
    * Sintaxis: LASTROWID [BD_ID]
    * Ejemplo: LASTROWID 8
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 13 LASTROWID OK WITH ROWID [ROW_ID]
        * 14 FAILED LASTROWID SQLITE
        * 15 FAILED LASTROWID BD DOES NOT EXISTS 

* **softheap**: Limita el tamaño de las bases de datos
    * Sintaxis: SOFTHEAP [SIZE]
    * Ejemplo: SOFTHEAP 10000000
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 16 SOFTHEAP OK
        * 17 FAILED SOFTHEAP SQLITE

* **hardheap**: Limita el tamaño de las bases de datos y da error si este tamaño es superado
    * Sintaxis: HARDHEAP [SIZE]
    * Ejemplo: HARDHEAP 10000000
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 18 HARDHEAP OK
        * 19 FAILED HARDHEAP SQLITE

* **blobin**: Inserta un blob en la bd
    * Sintaxis: BLOBIN [BD_ID] [BD_TABLE] [FILENAME] [FILEPATH]
    * Ejemplo: BLOBIN 5 Music song.mp3 path/to/song.mp3
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 20 BLOBIN OK
        * 21 FAILED BLOBIN BD DOES NOT EXISTS
        * 22 FAILED BLOBIN FILESYSTEM
        * 23 FAILED BLOBIN SQLITE

* **blobout**: Extrae un blob de la bd
    * Sintaxis: BLOBOUT [BD_ID] [BD_TABLE] [FILENAME] [FILEPATH]
    * Ejemplo: BLOBOUT 5 Music song.mp3 path/to/song.mp3
    * Retorno: El comando retorna -1 si la función writebuf retorna -1; en otro caso, retorna 0
    * Códigos: Los códigos que enviará la función al cliente, dependiendo de su ejecución son:
        * 24 BLOBOUT OK
        * 25 FAILED BLOBIN BD DOES NOT EXISTS
        * 26 FAILED BLOBIN FILESYSTEM
        * 27 FAILED BLOBIN SQLITE

* **exit**: finaliza la ejecución de xs_sqlite y no libera los recursos
    * Sintaxis: EXIT
    
* **terminate**: finaliza la ejecución de xs_sqlite y libera los recursos
    * Sintaxis: TERMINATE
